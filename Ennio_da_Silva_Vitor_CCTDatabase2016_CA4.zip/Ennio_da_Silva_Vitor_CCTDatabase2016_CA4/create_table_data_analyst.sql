CREATE TABLE insurance.data_analyst (
id_data_analyist INT NOT NULL AUTO_INCREMENT,
surname VARCHAR(50),
f_name VARCHAR(50),
interest_area VARCHAR(50),
creation_date VARCHAR(10),
last_used_date VARCHAR(10),
e_mail VARCHAR(50) NULL,
phone_number VARCHAR(50),
PRIMARY KEY (id_data_analyist)
)