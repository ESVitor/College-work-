INSERT INTO insurance.car (id_car, model, year, engine, registration, maker, company_id_company, policy_id_policy) 
VALUES (1, 'Aldi r8', '2015', '5.2', '15D0000', 'Aldi', 1, 1);
