CREATE TABLE insurance.company (
id_company INT NOT NULL AUTO_INCREMENT,
company_name VARCHAR(45),
address VARCHAR(50),
phone_number VARCHAR(50),
city VARCHAR(50),
type VARCHAR(50),
PRIMARY KEY (id_company)
)
