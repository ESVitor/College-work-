INSERT INTO insurance.company (id_company, company_name, address, phone_number, city, type) VALUES (1, 'Ennio\'s insurance', '9 The drive, Tallaght, Dublin 24', '0877035958', 'Dublin', 'Broker');


