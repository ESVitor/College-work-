INSERT INTO insurance.policy (id_policy, policy_description, policy_date, policy_expired_date, policy_price, policy_content) 
VALUES (1, 'Car insurance', '2015-11-09', '2015-11-09', 6500.00, 'paragraphs: .....');
