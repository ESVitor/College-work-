INSERT INTO insurance.data_analyst (id_data_analyst, surname, f_name, interest_area, creation_date, last_used_date, e_mail, phone_number) 

VALUES (1, 'da Silva Vitor', 'Ennio', 'Car insurance ', '2016-11-09', '2016-11-16', 'ennio.vitor@hotmail.com', '0877035958');
