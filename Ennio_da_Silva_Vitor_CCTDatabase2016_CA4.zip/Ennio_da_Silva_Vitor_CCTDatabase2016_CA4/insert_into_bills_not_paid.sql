INSERT INTO insurance.bills_not_paid (id_bills_not_paid, bills_name, bill_description, bill_date, bill_time, bills_expired, data_analyst_id_data_analyst) 

VALUES (1, 'Car insurance', 'based in Dublin', '2015-11-09', '00:00:00', '2016-11-09', 1);
