INSERT INTO insurance.customer (id_customer, f_name, surname, dob, address, phone_number) 

VALUES (1, 'Abraham', 'Lincoln', '1809-02-12', '9 The drive, Tallaght, Dublin 24', '0877035958');
